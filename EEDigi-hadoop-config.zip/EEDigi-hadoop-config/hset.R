Sys.setenv("HADOOP_PREFIX"="/home/ubuntu/hadoop/")
Sys.setenv("HADOOP_CMD"="/home/ubuntu/hadoop/bin/hadoop")
Sys.setenv("HADOOP_STREAMING"="/home/ubuntu/hadoop/share/hadoop/tools/lib/hadoop-streaming-2.7.2.jar")
library(rmr2)